import React from "react";
import ReactDOM from "react-dom";
import "antd/dist/antd.css";
import "./index.css";
import { Row, Col, Divider, Avatar } from "antd";
import { UserOutlined } from "@ant-design/icons";

const UserID = "6079858623c4150084b79241";

const fs = require("fs");

let rawdata = fs.readFileSync("users.json");
let users = JSON.parse(rawdata);

console.log(users);

let user = "";
var i;
for (i = 0; i < users.length; i++) {
  if (users[i]["_id"]["$oid"] === UserID) {
    user = users[i]["username"];
    break;
  }
}

const Bio = "This would be where the bio is... IF I HAD ONE. Mostly because things seem to be working fine, it just needs some fixing to get things done and make this field a read from file"
const AvatarImage = "https://cdn.discordapp.com/attachments/448978250081894413/825743665816535040/162902799_799223194347664_2472862927620242404_n.png"
const UserName = user;

ReactDOM.render(
  <>
    <Row justify="center" align="middle">
      <Col flex={4}></Col>
      <Col span={2}>
        <Avatar
          size={{ xs: 24, sm: 32, md: 40, lg: 64, xl: 80, xxl: 100 }}
          src={AvatarImage}
        />
      </Col>
      <Col flex={4}>{UserName}</Col>
      <Col flex={2}></Col>
    </Row>

    <Divider orientation="left"></Divider>
    <Row justify="space-around" align="middle">
      <Col span={8}>
        {Bio}
      </Col>
    </Row>
  </>,
  document.getElementById("container")
);
